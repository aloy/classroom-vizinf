# Files contained in the online supplement for 
# "Bringing Visual Inference to the Classroom"
# by Adam Loy

## Files for comparing means example  
* compare_means_code.Rmd - R code to generate lineups
* compare_means_lineup_intsr.docx - Instructors guide with annotate activity
* compare_means_lineup_student.docx - Blank activity for students
* CreativeWriting.csv is found in the data folder
* PDF images are in fig folder

## Files for residual example
* residual_lineup_code.Rmd - R code to generate lineups
* residual_lineup_instr.docx - Instructors guide with annotate activity
* residual_lineup_student.docx - Blank activity for students
* RailsTrails.csv is found in the data folder
* PDF images are in fig folder